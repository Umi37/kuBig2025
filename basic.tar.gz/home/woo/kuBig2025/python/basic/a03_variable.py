def main():
    # C 에서 변수 설정
    # int a;
    # a = 10;
    a = 10 # python 에서는 선언이 필요 없음
    b = 10
    print(a + b)
    a = "hi" # python 에서는 type 에 상관 없이 값을 대입 할 수 있음
    print(a * b)

if __name__ == "__main__":
    main()

