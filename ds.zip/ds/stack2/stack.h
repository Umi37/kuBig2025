// #pragma once 
#ifndef STACK_H
#define STACK_H

void push(int data);    // func. declaration
int pop(void);

#endif
