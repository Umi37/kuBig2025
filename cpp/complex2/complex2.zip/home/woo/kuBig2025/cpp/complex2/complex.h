#ifndef COMPLEX_H
#define COMPLEX_H

class Complex {
    public :
        Complex();                          // default constructor (기본 생성자, 기저 생성자 - 입력값이 없는 생성자)
        Complex(double re);                 // convert constructor (변환 생성자 - 입력값이 하나 있는 생성자)
        Complex(double re, double im);
        ~Complex();

    private :
        double re;
        double im;

        void real(double re);
        void imag(double im);
        
};

#endif
