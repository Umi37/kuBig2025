def main():
    print("Hello from gravity-pygame!")


if __name__ == "__main__":
    main()
