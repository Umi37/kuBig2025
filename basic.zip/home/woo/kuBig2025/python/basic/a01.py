import a02_keyword

print("hello, world")

def print_hello():
    print("fuction hello")
    print("2function hello")
    print("3function")

def print_hello2():
    pass
        
print_hello()

